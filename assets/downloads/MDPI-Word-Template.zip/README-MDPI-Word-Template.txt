========================================================================
MDPI Manuscript & Conference Paper Template (Microsoft Word)
ICICSC 2027 — International Conference on Intelligent, Connected and Sustainable Computing
========================================================================

This package contains the official MDPI templates for Microsoft Word:

1. MDPI-Article-Template.docx
   Standard Microsoft Word document pre-configured with MDPI 2-column styles, 
   headings, metadata (authors, affiliations, abstract, keywords), tables, 
   equation styles, and bibliography formatting. Recommended for direct editing.

2. MDPI-Article-Template.dotx / .dot
   Microsoft Word Template files that can be installed into your Word Templates 
   folder or opened directly to generate a fresh document.

3. MDPI-Book-Chapter-Template.docx
   Official template for book chapter / proceedings contributions.

Guidelines for Authors:
- Maintain the margins, font styles, and paragraph formatting provided in this template.
- Papers must strictly adhere to the 8–10 page limit for regular technical papers.
- Ensure all figures and tables are properly captioned and cited in the text.
- Follow the citation style provided in the references section.

For more details on MDPI author guidelines, visit:
https://www.mdpi.com/authors
